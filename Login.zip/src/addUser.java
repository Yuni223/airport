import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import javax.swing.*;

@SuppressWarnings("serial")

public class addUser extends JFrame
{
	public addUser()
	{
		JPanel p = new JPanel();
		
		Label l1 = new Label("ID : ");
		TextField t1 = new TextField();
		Label l2 = new Label("PW : ");
		TextField t2 = new TextField();
		Label l3 = new Label("���� : ");
		TextField t3 = new TextField("XXXXXX");
		Label l4 = new Label("�ּ� : ");
		TextField t4 = new TextField();
		Label l5 = new Label("Ư�̻��� : ");
		TextField t5 = new TextField("����.");
		
		/* �� */
		add(l1);
		l1.setBounds(40,10,40,40);
		add(l2);
		l2.setBounds(40,50,40,40);
		add(l3);
		l3.setBounds(40,90,60,40);
		add(l4);
		l4.setBounds(40,130,40,40);
		add(l5);
		l5.setBounds(40,170,60,40);
		
		/* �ؽ�Ʈ�ʵ� */
		add(t1);
		t1.setBounds(120,10,200,30);
		add(t2);
		t2.setBounds(120,50,200,30);
		t2.setEchoChar('*'); // ��й�ȣ�� ���� �Է¹���
		add(t3);
		t3.setBounds(120,90,200,30);
		add(t4);
		t4.setBounds(120,130,280,30);
		add(t5);
		t5.setBounds(120,180,280,120);
		
		/* ��ư */
		JButton j1 = new JButton("����");
		add(j1);
		j1.setBounds(125,330,80,30);
		JButton j2 = new JButton("���");
		add(j2);
		j2.setBounds(240,330,80,30);
		JButton j3 = new JButton("�ߺ�Ȯ��");
		add(j3);
		j3.setBounds(360,10,100,30);
		
		add(p);
		setSize(500,420);
		setTitle("ȸ������");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		j1.addActionListener(new ActionListener() // ȸ������
				{
					public void actionPerformed(ActionEvent e)
					{
						if(t1.getText().equals("") || t2.getText().equals(""))
						{
							JOptionPane.showMessageDialog(null,"���̵� ��й�ȣ�� ä���ּ���.");
						}
						else
						{
							try 
							{
								String s;
								BufferedReader bos = new BufferedReader(new FileReader("ȸ������.txt"));
								boolean check = false;

								while ((s = bos.readLine()) != null)
								{
									String[] array = s.split("/");
									if (t1.getText().equals(array[0]))
									{
										check = true;
										break;
									}
								}
								bos.close();
								if (check)
								{
									JOptionPane.showMessageDialog(null, "ID Checking Please");
								}
							else
								{
									BufferedWriter bos1 = new BufferedWriter(new FileWriter("ȸ������.txt", true));
									bos1.write(t1.getText() + "/");
									bos1.write(t2.getText() + "/");
									bos1.write(t3.getText() + "/");
									bos1.write(t4.getText() + "/");
									bos1.write(t5.getText() + "\r\n\n");
									bos1.close();
									JOptionPane.showMessageDialog(null, "ȸ�������� �����մϴ�.");
									
									new LoginPage(); // �α��� �������� �̵�
									setVisible(false); // ���� â�� �ݽ��ϴ�.
								}
								}catch(Exception ex)
								{JOptionPane.showMessageDialog(null,"Error");}
						}
					}
				});
		j2.addActionListener(new ActionListener() // ���
		{
			public void actionPerformed(ActionEvent e)
			{
				new LoginPage();
				setVisible(false);
			}
		});
		j3.addActionListener(new ActionListener() // �ߺ�Ȯ��
		{
			public void actionPerformed(ActionEvent e)
			{
				try 
				{
					String s;
					BufferedReader bos = new BufferedReader(new FileReader("ȸ������.txt"));
					boolean check = false;

					while ((s = bos.readLine()) != null)
					{
						String[] array = s.split("/");
						if (t1.getText().equals(array[0]))
						{
							check = true;
							break;
						}
					}
					bos.close();
					if (check)
					{
						JOptionPane.showMessageDialog(null, "��� �Ұ����� ���̵� �Դϴ�.");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "��� ������ ���̵� �Դϴ�.");
					}
				}catch(Exception ex)
					{JOptionPane.showMessageDialog(null,"Error");}
			}
		});
	}
	public static void main(String [] args)
	{
		new addUser();
	}
}