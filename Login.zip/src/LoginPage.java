import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

@SuppressWarnings("serial")

public class LoginPage extends JFrame
{
	Image img = null;
	public LoginPage()
	{
		JPanel p = new JPanel();
		p.setLayout(null);
		
		JLabel imglabel = new JLabel (new ImageIcon("Login\\����.PNG"));
		imglabel.setBounds(0, 5, 350, 255);
		add(imglabel);
		
		Label id = new Label("���̵�:");
		id.setBounds(40, 265, 40, 40);
		add(id);
		TextField tfid = new TextField();
		tfid.setBounds(150, 265, 200, 30);
		add(tfid);

		Label pw= new Label("��й�ȣ:");
		pw.setBounds(40, 305, 60, 40);
		add(pw);
		TextField tfpw = new TextField();
		tfpw.setBounds(150, 305, 200, 30);
		add(tfpw);
		tfpw.setEchoChar('*'); //��ȣȭ
		
		JButton login = new JButton("�α���");
		login.setBounds(380, 265, 80, 30);
		add(login);
		
		JButton useradd = new JButton("ȸ������");
		useradd.setBounds(380, 305, 90, 30);
		add(useradd);
		
		add(p);
		setSize(700, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("�α��� ȭ�� ");
		setVisible(true);
		
		login.addActionListener(new ActionListener() // �α��� ����
		{
			public void actionPerformed(ActionEvent e2) 
			{
				try{
					String s;
					BufferedReader bos = new BufferedReader(new FileReader("ȸ������.txt"));
					
					boolean login = false;
					
					if(tfid.getText() == null)
					{
						JOptionPane.showMessageDialog(null, "���̵� �Է����ּ���.");
					}
					else
					{
						while((s=bos.readLine())!=null)
						{
							String[] array = s.split("/");
							if(tfid.getText().equals(array[0])&&tfpw.getText().equals(array[1]))
							{
								login = true;
								break;
							}
							else 
							{
								login = false;
							}
						}
					}
					if(login)
					{
						JOptionPane.showMessageDialog(null, "Login Complete");
						setVisible(false);
						//new dfkljd();
					}
					else
					{
						JOptionPane.showMessageDialog(null, "���̵� Ȥ�� �н����尡 �߸��Ǿ����ϴ�.");
					}
					bos.close();
				}catch (IOException E10){E10.printStackTrace();}
			}
		});
		
		useradd.addActionListener(new ActionListener() // ȸ������(addUser�� �̵�)
		{
			public void actionPerformed(ActionEvent e) 
			{
				new addUser(); // ȸ������ �������� �̵��Ҷ�, Visible = false
				setVisible(false);
			}
		});
	}
	public static void main(String [] args)
	{
		new LoginPage();
	}
}
